<?php 
	print_r($dataKaryawan->nama_belakang);
?>