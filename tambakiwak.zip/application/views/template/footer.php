	<footer class="navbar bg-dark navbar-dark"> 
		<span class="ml-auto">@weecom</span>
	</footer>
</body>
</html>