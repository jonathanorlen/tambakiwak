<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title?></title>

	<!-- Required meta tags -->
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap/bootstrap.min.css')?>">
</head>
<body>
	<nav class="navbar navbar-dark bg-dark">
		<a href="<?php echo base_url()?>" class="navbar-brand">WEECom</a>
	</nav>
	Ini kontent
